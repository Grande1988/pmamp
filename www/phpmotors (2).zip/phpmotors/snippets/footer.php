<p>&#169; PHP Motors, All rights reserved.</p>
<p>Images are believed to be "Fair Use". Notify the autor
    if not and they will be removed,</p>
     <?php echo "Last Updated: " . date("F d, Y", getlastmod());?>