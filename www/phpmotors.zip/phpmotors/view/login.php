<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - PHP Motors</title>
    <link rel= "stylesheet" href="http://fonts.gstatic.com">
    <link href="httpsL//fonts.googleapis.com/css?family=Electrolize&family=Share+Tech&display=swap" rel="stylesheet">
    <link rel="stylesheet" href = "../css/style.css">
    <link rel="stylesheet" media="screen" href = "/css/main.css">
</head>
<body>
    <div class = "page">
        <header>
            <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/header.php'; ?>
        </header>
        <nav>
      <?php echo $navList; ?>
    </nav>  
<h2>Login</h2>
    <form action="login_process.php" method="post">
        <!-- line 14 needs somethin -->
        <!-- /phpmotors/accounts/index.php -->
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br><br>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br><br>

        <input type="submit" id="login" value="Login">

        <h3>No Account? <a href="/phpmotors/accounts/index.php?action=registration">Register</a></h3>

    </form>
    </div>
    <?php include $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/footer.php'; ?>
</body>
</html>