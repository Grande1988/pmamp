<?php
// if (!$_SESSION['loggedin'] || $_SESSION['clientData']['clientLevel'] <= 1){
//     header('Location: /index.php/');
// }

// // Build a car classification drop down list.
// $carClassifications = "<select name = 'carClassifications'>";
// foreach($classifications as $classification) {
//     $tag = '<option value=""';
    
//     if(isset($classType)){
//         if ($classification['classificationId'] === $classType){
//             $tag .= ' selected ';
//         }
//     }

//     $tag .= '>'.$classification['classificationName'].'</option>';
//     $tag = substr_replace($tag, $classification['classificationId'], 15, 0);
//     $carClassifications .= $tag;
// }
// $carClassifications .= '</select>';

?><!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Vehicle</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Electrolize&family=Share+Tech&display=swap" rel="stylesheet">
    <link rel = "stylesheet" href = "/css/normalize.css">
    <link rel="stylesheet" href = "../css/style.css">
</head>
<body>
    <div class = "page">
        <header>
            <?php require $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/header.php'; ?>
        </header>
        <nav>
            <?php echo $navList; ?>
        </nav>
        <main>
        <h2>Add Vehicle</h2>
    <!-- <p>*All Fields are Required</p> -->
    <div class=" form">
      <?php
      if (isset($message)) {
        echo $message;
      }
      ?>
            <form action="/phpmotors/vehicles/index.php" method="post">
            <label for="classificationId">Select Classification</label><br>
        <select name="classificationId" id="classificationId">
          <option value="">Select an Option</option>
          <?php
          $classificationList = [
            ["classificationId" => 1, "classificationName" => "SUV"],
            ["classificationId" => 2, "classificationName" => "Classic"],
            ["classificationId" => 3, "classificationName" => "Sports"],
            ["classificationId" => 4, "classificationName" => "Trucks"],
            ["classificationId" => 5, "classificationName" => "Used"],
            // Add more classification data as needed
          ];

          foreach ($classificationList as $classification) {
            echo "<option value='" . $classification['classificationId'] . "'>" . $classification['classificationName'] . "</option>";
          }
          ?>
          </select>
          <br><br>
          <label for="invMake">Make</label>
        <br>
        <input type="text" name="invMake" id="invMake" placeholder="ex. Lincoln">
        <br><br>
        <label for="invModel">Model</label>
        <br>
        <input type="text" name="invModel" id="invModel" placeholder="ex Navigator">
        <br><br>
        <label for="invDescription">Desription</label>
        <br>
        <input type="text" name="invDescription" id="invDescription" placeholder="ex. luxury">
        <br><br>
        <label for="invImage">Image Path</label>
        <br>
        <input type="text" value="/images/no-image.png" name="invImage" id="invImage">
        <br><br>
        <label for="invThumbnail">Thumbnail Path</label>
        <br>
        <input type="text" value="/images/no-image.png" name="invThumbnail" id="invTHumbnail">
        <br><br>
        <label for="invPrice">Price</label>
        <br>
        <input type="number" name="invPrice" id="invPrice" pattern="^\$\d{1,3}(,\d{3})*(\.\d+)?$" placeholder="ex. 87000" data-type="currency">
        <br><br>
        <label for="invStock"># in Stock</label>
        <br>
        <input type="number" name="invStock" id="invStock" placeholder="ex. 3">
        <br><br>
        <label for="invColor">Color</label>
        <br>
        <input type="text" name="invColor" id="invColor" placeholder=" ex. Blue">
        <br><br>


        <input type="submit" value="Add Vehicle">
        <input type="hidden" name="action" value="addVehicle">
</form>
</main>
  </div>
  </main>

  <!-- Footer section -->
  <?php include $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/footer.php'; ?>

</body>

</html>