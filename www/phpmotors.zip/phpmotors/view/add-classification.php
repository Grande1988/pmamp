<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name= "viewport" content="width=device-width, initial-scale=1.0">
        <title>PHP Motors
        <!-- Link to the CSS stylesheet with the media="screen" attribute -->
        <link rel="" href="http://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Electrolize&family=Share+Tech&display=swap" rel="stylesheet">
        <link rel="stylesheet" href = "../css/style.css">
        <link rel = "stylesheet" href = "/css/normalize.css">
    <link rel="stylesheet" href = "../css/style.css">
        </title>
    </head>
    <body>

<div>
    <!-- header section -->
    <?php require_once $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/header.php'; ?> 
    <!-- Navigation section -->
    <nav>
            <?php echo $navList; ?>
        </nav>
</div>


    <main>
        <h2>Add Vehicle Classification</h2>
        <?php
        if (isset($message)) {
            echo $message;
          }
        ?>
        <form action="/phpmotors/vehicles/index.php" method="post">

        <label for="newClassification">Classification Name</label><br>
        <input type="text" name="newClassification" id="newClassification"><br><br>
        <input type="submit" value="Add Classification">
        <input type="hidden" name="action" value="addClass">
        </form>
    </main>
    <?php include $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/footer.php'; ?>
    </body>
</html>