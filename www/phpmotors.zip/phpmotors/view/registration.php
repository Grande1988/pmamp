<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration - PHP Motors</title>
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Electrolize&family=Share+Tech&display=swap" rel="stylesheet">
    <link rel = "stylesheet" href = "/css/normalize.css">
    <link rel = "stylesheet" media="screen" href = "/css/main.css">
</head>
<body>
    <div class = "page">
        <header>
            <?php require $_SERVER['DOCUMENT_ROOT'] . '/snippets/header.php'; ?>
        </header>
        <nav>
            <?php echo $navList; ?>
        </nav>
        <main>
            <h1>Registration</h1>
            <form action="registration_process.php" method="post">
            <label for="firstName">First Name:</label>
            <input type="text" name="firstName" name="firstName" required><br><br>

            <label for="lastName">Last Name:</label>
            <input type="text" name="lastName" name="lastName" required><br><br>

            <label for="email">Email:</label>
            <input type="email" name="email" name="email" required><br><br>

            <label for="password">Password:</label>
            <input type="password" name="password" name="password" required><br><br>

            <input type="submit" value="Register">
            <input type="hidden" name="action" value="register">
        </form>
    </main>

    <!-- Footer section -->
    
    <?php include $_SERVER['DOCUMENT_ROOT'] . '/phpmotors/snippets/footer.php'; ?>
</body>

</html>