<?php
// This is the accounts model page

// This function will handle site registrations 
function regClient($clientFirstname, $clientLastname, $clientEmail, $clientPassword ){

//connection object   
  $db = phpmotorsConnect();

// SQL statement  
  $sql = 'INSERT INTO clients(clientFirstname, clientLastname, clientEmail, clientPassword)
  VALUES (:clientFirstname, :clientLastname, :clientEmail, :clientPassword)';

  $stmt = $db->prepare($sql);
  // these liines replace the placeholders in the SQL statement with the actual values in the variables and tells db type of data it is 
  $stmt->bindValue(':clientFirstname', $clientFirstname, PDO::PARAM_STR);
  $stmt->bindValue(':clientLastname', $clientLastname, PDO::PARAM_STR);
  $stmt->bindValue(':clientEmail', $clientEmail, PDO::PARAM_STR);
  $stmt->bindValue(':clientPassword', $clientPassword, PDO::PARAM_STR);

  // Insert the Data 
  $stmt->execute();

  //  Ask how many rows changed as a result of our insert 
  $rowsChanged = $stmt->rowCount();

  // close db interaction 
  $stmt->closeCursor();

  //  return indicationof success 
  return $rowsChanged;
}
?>