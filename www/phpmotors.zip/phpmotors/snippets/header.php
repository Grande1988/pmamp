<header>
    <div>
        <img class="logo" src="/phpmotors/images/site/logo.png" alt="PHP Motors logo">
        <?php echo '<a href="/phpmotors/accounts/index.php?action=login">MyAccount</a>' ?>
<!-- task 5 in week 4 enhancement -->
    </div>
</header>

