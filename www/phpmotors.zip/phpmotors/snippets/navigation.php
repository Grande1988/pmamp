    <ul>
        <li><a href="/phpmotors/view/home.php/" title="PHP Motors home page">Home</a></li>
        <li><a href="#classics" title="classic cars page">Classic</a></li>
        <li><a href="#sports" title="sports cars">Sports</a></li>
        <li><a href="#suv" title="sports utility vehicles">SUV</a></li>
        <li><a href="#suv" title="trucks">Trucks</a></li>
        <li><a href="#used" title="used cars">Used</a></li>
    </ul>
